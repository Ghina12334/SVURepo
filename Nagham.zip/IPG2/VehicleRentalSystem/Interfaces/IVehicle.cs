namespace VehicleRentalSystem.Interfaces;

/// <summary>
/// Contract for rental vehicles exposing identity, presentation, and cost calculation.
/// </summary>
public interface IVehicle
{
    /// <summary>Manufacturer or marketing model name.</summary>
    string Model { get; }

    /// <summary>Government registration identifier (read-only from consumers).</summary>
    string LicensePlate { get; }

    /// <summary>Outputs human-readable vehicle information.</summary>
    void DisplayDetails();

    /// <summary>Computes rental charge for the given number of whole days.</summary>
    decimal CalculateRentalCost(int days);
}
