using VehicleRentalSystem.Interfaces;
using VehicleRentalSystem.Services;

namespace VehicleRentalSystem.Abstracts;

/// <summary>
/// Shared vehicle state and polymorphic hooks; participates in inheritance from <see cref="IVehicle"/>.
/// </summary>
public abstract class Vehicle : IVehicle
{
    private readonly string _model;
    private readonly string _licensePlate;
    private readonly int _year;
    private bool _isRented;

    /// <summary>Creates a validated vehicle identity (increments <see cref="TotalVehiclesCreated"/>).</summary>
    protected Vehicle(string model, string licensePlate, int year)
    {
        Validator.IsValidModel(model);
        Validator.IsValidPlate(licensePlate);
        Validator.IsValidYear(year);

        _model = model.Trim();
        _licensePlate = licensePlate.Trim().ToUpperInvariant();
        _year = year;

        TotalVehiclesCreated++;
    }

    /// <summary>Tracks how many <see cref="Vehicle"/> instances have been constructed.</summary>
    public static int TotalVehiclesCreated { get; private set; }

    /// <inheritdoc />
    public string Model => _model;

    /// <inheritdoc />
    public string LicensePlate => _licensePlate;

    /// <summary>Model year (validated at construction).</summary>
    public int Year => _year;

    /// <summary>Indicates whether this unit is currently on rent.</summary>
    public bool IsRented
    {
        get => _isRented;
        internal set => _isRented = value;
    }

    /// <inheritdoc />
    public virtual void DisplayDetails()
    {
        Console.WriteLine($"  Model: {Model}, Plate: {LicensePlate}, Year: {Year}");
    }

    /// <inheritdoc />
    public abstract decimal CalculateRentalCost(int days);
}
