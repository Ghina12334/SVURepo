namespace VehicleRentalSystem.Delegates;

/// <summary>Signature for observers of rental lifecycle events.</summary>
public delegate void RentalTransactionHandler(object sender, string message);
