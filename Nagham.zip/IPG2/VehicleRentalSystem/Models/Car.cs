using VehicleRentalSystem.Abstracts;

namespace VehicleRentalSystem.Models;

/// <summary>Passenger car with tiered passenger and fuel metadata.</summary>
public class Car : Vehicle
{
    private readonly int _passengerCapacity;
    private readonly string _fuelType;

    /// <summary>Constructs a <see cref="Car"/>.</summary>
    public Car(string model, string licensePlate, int year, int passengerCapacity, string fuelType)
        : base(model, licensePlate, year)
    {
        if (passengerCapacity < 1 || passengerCapacity > 15)
            throw new ArgumentOutOfRangeException(nameof(passengerCapacity), "Capacity must be between 1 and 15.");
        if (string.IsNullOrWhiteSpace(fuelType))
            throw new ArgumentException("Fuel type is required.", nameof(fuelType));

        _passengerCapacity = passengerCapacity;
        _fuelType = fuelType.Trim();
    }

    /// <summary>Seating capacity excluding driver assumptions.</summary>
    public int PassengerCapacity => _passengerCapacity;

    /// <summary>Primary fuel classification (e.g. Gasoline, Diesel, Hybrid).</summary>
    public string FuelType => _fuelType;

    /// <inheritdoc />
    public override decimal CalculateRentalCost(int days)
    {
        if (days < 1)
            throw new ArgumentOutOfRangeException(nameof(days), "Days must be at least 1.");
        return 50.00m * days;
    }

    /// <inheritdoc />
    public override void DisplayDetails()
    {
        base.DisplayDetails();
        Console.WriteLine($"    [Car] Passengers: {PassengerCapacity}, Fuel: {FuelType}");
    }
}
