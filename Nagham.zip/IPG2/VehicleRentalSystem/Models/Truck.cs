using VehicleRentalSystem.Abstracts;

namespace VehicleRentalSystem.Models;

/// <summary>Commercial truck with payload and axle metadata.</summary>
public class Truck : Vehicle
{
    private readonly decimal _maxPayloadTons;
    private readonly int _axleCount;

    /// <summary>Constructs a <see cref="Truck"/>.</summary>
    public Truck(string model, string licensePlate, int year, decimal maxPayloadTons, int axleCount)
        : base(model, licensePlate, year)
    {
        if (maxPayloadTons <= 0 || maxPayloadTons > 200)
            throw new ArgumentOutOfRangeException(nameof(maxPayloadTons), "Payload must be between 0 and 200 tons.");
        if (axleCount < 2 || axleCount > 10)
            throw new ArgumentOutOfRangeException(nameof(axleCount), "Axle count must be between 2 and 10.");

        _maxPayloadTons = maxPayloadTons;
        _axleCount = axleCount;
    }

    /// <summary>Maximum rated payload in metric tons.</summary>
    public decimal MaxPayloadTons => _maxPayloadTons;

    /// <summary>Number of axles on the chassis.</summary>
    public int AxleCount => _axleCount;

    /// <inheritdoc />
    public override decimal CalculateRentalCost(int days)
    {
        if (days < 1)
            throw new ArgumentOutOfRangeException(nameof(days), "Days must be at least 1.");
        return 120.00m * days;
    }

    /// <inheritdoc />
    public override void DisplayDetails()
    {
        base.DisplayDetails();
        Console.WriteLine($"    [Truck] Max payload (tons): {MaxPayloadTons}, Axles: {AxleCount}");
    }
}
