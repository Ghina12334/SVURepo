using VehicleRentalSystem.Abstracts;

namespace VehicleRentalSystem.Models;

/// <summary>Two-wheel vehicle with displacement and optional sidecar flag.</summary>
public class Motorcycle : Vehicle
{
    private readonly int _engineCc;
    private readonly bool _hasSidecar;

    /// <summary>Constructs a <see cref="Motorcycle"/>.</summary>
    public Motorcycle(string model, string licensePlate, int year, int engineCc, bool hasSidecar)
        : base(model, licensePlate, year)
    {
        if (engineCc < 50 || engineCc > 3000)
            throw new ArgumentOutOfRangeException(nameof(engineCc), "Engine displacement must be between 50 and 3000 CC.");

        _engineCc = engineCc;
        _hasSidecar = hasSidecar;
    }

    /// <summary>Engine displacement in cubic centimeters.</summary>
    public int EngineCC => _engineCc;

    /// <summary>Whether a sidecar is equipped.</summary>
    public bool HasSidecar => _hasSidecar;

    /// <inheritdoc />
    /// <remarks>$30/day for the first three days, $20/day thereafter.</remarks>
    public override decimal CalculateRentalCost(int days)
    {
        if (days < 1)
            throw new ArgumentOutOfRangeException(nameof(days), "Days must be at least 1.");

        const decimal firstTierRate = 30.00m;
        const decimal afterTierRate = 20.00m;
        const int tierThreshold = 3;

        var firstTierDays = Math.Min(days, tierThreshold);
        var remaining = Math.Max(0, days - tierThreshold);

        return firstTierDays * firstTierRate + remaining * afterTierRate;
    }

    /// <inheritdoc />
    public override void DisplayDetails()
    {
        base.DisplayDetails();
        Console.WriteLine($"    [Motorcycle] Engine: {EngineCC} CC, Sidecar: {(HasSidecar ? "Yes" : "No")}");
    }
}
