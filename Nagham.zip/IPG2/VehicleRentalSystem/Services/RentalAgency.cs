using VehicleRentalSystem.Abstracts;
using VehicleRentalSystem.Delegates;

namespace VehicleRentalSystem.Services;

/// <summary>Rental facade: fleet lifecycle, polymorphic display, and domain events.</summary>
public class RentalAgency
{
    private readonly List<Vehicle> _fleet = [];

    /// <summary>Raised after a vehicle is successfully rented (includes plate in message).</summary>
    public event RentalTransactionHandler? OnVehicleRented;

    /// <summary>Raised after a vehicle is returned with days and computed cost in the message.</summary>
    public event RentalTransactionHandler? OnVehicleReturned;

    /// <summary>Adds a vehicle to the fleet if the plate is not already tracked.</summary>
    public void AddVehicle(Vehicle v)
    {
        if (_fleet.Any(x => string.Equals(x.LicensePlate, v.LicensePlate, StringComparison.OrdinalIgnoreCase)))
            throw new InvalidOperationException($"A vehicle with plate '{v.LicensePlate}' already exists.");

        _fleet.Add(v);
    }

    /// <summary>Removes a vehicle by license plate.</summary>
    /// <returns><c>true</c> when removed.</returns>
    public bool RemoveVehicle(string plate)
    {
        var found = FindByPlate(plate);
        if (found == null)
            return false;
        _fleet.Remove(found);
        return true;
    }

    /// <summary>Demonstrates polymorphism: each subtype prints via overridden <see cref="Vehicle.DisplayDetails"/>.</summary>
    public void ShowFleet()
    {
        Console.WriteLine("--- Fleet (polymorphic DisplayDetails) ---");
        foreach (var v in _fleet)
            v.DisplayDetails();
        Console.WriteLine();
    }

    /// <summary>Marks vehicle as rented and notifies subscribers.</summary>
    public void ProcessRental(string plate)
    {
        var vehicle = FindByPlate(plate) ?? throw new InvalidOperationException($"No vehicle found for plate '{plate}'.");
        if (vehicle.IsRented)
            throw new InvalidOperationException($"Vehicle '{plate}' is already rented.");

        vehicle.IsRented = true;
        var msg = $"RENTED: License plate {vehicle.LicensePlate} ({vehicle.Model}) is now checked out.";
        OnVehicleRented?.Invoke(this, msg);
    }

    /// <summary>Completes rental, computes cost via subtype pricing, resets availability.</summary>
    public void ProcessReturn(string plate, int days)
    {
        if (days < 1)
            throw new ArgumentOutOfRangeException(nameof(days), "Return days must be at least 1.");

        var vehicle = FindByPlate(plate) ?? throw new InvalidOperationException($"No vehicle found for plate '{plate}'.");
        if (!vehicle.IsRented)
            throw new InvalidOperationException($"Vehicle '{plate}' was not rented.");

        var cost = vehicle.CalculateRentalCost(days);
        vehicle.IsRented = false;
        var msg = $"RETURNED: License plate {vehicle.LicensePlate} after {days} day(s). Final cost: {cost:C}.";
        OnVehicleReturned?.Invoke(this, msg);
    }

    private Vehicle? FindByPlate(string plate) =>
        _fleet.FirstOrDefault(x => string.Equals(x.LicensePlate, plate.Trim(), StringComparison.OrdinalIgnoreCase));
}
