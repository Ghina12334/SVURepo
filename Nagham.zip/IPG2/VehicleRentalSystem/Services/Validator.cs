namespace VehicleRentalSystem.Services;

/// <summary>
/// Static validation helpers for domain invariants (throw-on-invalid).
/// </summary>
public static class Validator
{
    private const int MinYear = 1900;
    private static readonly int MaxYear = DateTime.UtcNow.Year + 1;

    /// <summary>Validates a non-empty model name.</summary>
    /// <exception cref="ArgumentException">When the model is invalid.</exception>
    public static void IsValidModel(string name)
    {
        if (string.IsNullOrWhiteSpace(name))
            throw new ArgumentException("Model cannot be null or whitespace.", nameof(name));
        if (name.Trim().Length < 2)
            throw new ArgumentException("Model must be at least two characters.", nameof(name));
    }

    /// <summary>Validates a plausible license plate (alphanumeric, length 3–12).</summary>
    /// <exception cref="ArgumentException">When the plate is invalid.</exception>
    public static void IsValidPlate(string plate)
    {
        if (string.IsNullOrWhiteSpace(plate))
            throw new ArgumentException("License plate cannot be null or whitespace.", nameof(plate));
        var normalized = plate.Trim().ToUpperInvariant();
        if (normalized.Length < 3 || normalized.Length > 12)
            throw new ArgumentException("License plate length must be between 3 and 12 characters.", nameof(plate));
        foreach (var c in normalized)
        {
            if (!char.IsLetterOrDigit(c) && c != '-' && c != ' ')
                throw new ArgumentException("License plate contains invalid characters.", nameof(plate));
        }
    }

    /// <summary>Validates model year boundaries (cannot be before 1900 or after current UTC year + 1).</summary>
    /// <exception cref="ArgumentException">When the year is out of range.</exception>
    public static void IsValidYear(int year)
    {
        if (year < MinYear || year > MaxYear)
            throw new ArgumentException($"Year must be between {MinYear} and {MaxYear} inclusive.", nameof(year));
    }
}
